from django.contrib import admin
from .models import AuditLog

# Register your models here.
admin.site.register(AuditLog)